<?= $this->extend('layout/theme'); ?>
<?= $this->section('content'); ?>
<section class="content pt-0">
    <div class="judul container p-5 m-2 justify-content-start">
        <span class="visi">Visi dan Misi</span>
    </div>
    <div class="container d-flex justify-content-center mt-2 mb-5">
        <img src="/img/visi-misi.png" class="img-fluid" />
    </div>
</section>

<?= $this->endSection(); ?>