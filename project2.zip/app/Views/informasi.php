<?= $this->extend('layout/theme'); ?>
<?= $this->section('content'); ?>
<section class="content pt-0">
    <div class="judul container p-5 m-2 justify-content-start ">
        <span class="visi">Informasi Layanan</span>
    </div>
    <div class="container d-flex justify-content-center mt-2 mb-5" style="width: 75%;">
        <span class="fs-3 mb-5" style="text-align: justify;">Kantor Kementrian Agraria dan Tata Ruang (ATR)/Badan Pertanahan Nasional (BPN) Kota Tasikmalaya adalah lembaga pemerintah non departemen yang berkoordinasi langsung dengan Badan Pertanahan Nasional (BPN). Badan Pertanahan Nasional (BPN) sendiri berada di bawah tanggung jawab kepada presiden dan pimpinan oleh kepala (sesuai Perpres No. 20 Tahun 2015).</span>
    </div>
</section>

<?= $this->endSection(); ?>